package com.example.a03_android

class Main2Activity {
}