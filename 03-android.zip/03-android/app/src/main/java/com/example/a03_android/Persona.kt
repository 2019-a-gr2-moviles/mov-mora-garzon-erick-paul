package com.example.a03_android

class Persona(var nombre: String, var cedula: String) {

}